// Box.asm
//
// Roll number 2501730081  ->  K = 81
//
//   starting row   = K                      = 81
//   box height     = 20 rows                = rows 81 .. 100
//   box width      = 16 x ((K mod 4) + 1)
//                  = 16 x ((81 mod 4) + 1)
//                  = 16 x 2                 = 32 pixels  = 2 words per row
//   first word     = SCREEN + 32 * 81
//                  = 16384  + 2592          = 18976
//
// While any key is held the box is black; when nothing is held it is erased.
// Both cases run the same painting loop -- only the value written changes,
// -1 for black and 0 for white. Writing the same loop twice would be the
// obvious way and also the easy way to get the two copies out of step.
//
// Variables: colour, addr, rows, cols, p   (RAM 16..20)

(MAIN)
    @KBD
    D=M
    @SETBLACK
    D;JNE               // a key is down -> paint black
    @colour
    M=0                 // nothing held -> paint white (erase)
    @PAINT
    0;JMP
(SETBLACK)
    @colour
    M=-1                // all 16 bits on = 16 black pixels

(PAINT)
    @2592               // 32 words per row x 81 rows
    D=A
    @SCREEN
    D=D+A               // D = 18976, the box's top-left word
    @addr
    M=D
    @20                 // 20 rows to paint
    D=A
    @rows
    M=D

(ROWLOOP)
    @rows
    D=M
    @MAIN
    D;JEQ               // all rows done -> read the keyboard again
    @2                  // 2 words per row = 32 pixels
    D=A
    @cols
    M=D
    @addr
    D=M
    @p
    M=D                 // p walks across the row, addr stays at its start

(COLLOOP)
    @cols
    D=M
    @NEXTROW
    D;JEQ
    @colour
    D=M
    @p
    A=M
    M=D                 // write the colour into the screen word at p
    @p
    M=M+1
    @cols
    M=M-1
    @COLLOOP
    0;JMP

(NEXTROW)
    @32
    D=A
    @addr
    M=D+M               // next row starts 32 words further on
    @rows
    M=M-1
    @ROWLOOP
    0;JMP
