# Capstone — Nand to Tetris I

Roll number 2501730081, **K = 81**.

## Run the assembler

```
python assembler.py Box.asm          # -> Box.hack and symbols.txt
python assembler.py tests/Add.asm
```

## Layout

```
CPU.hdl Memory.hdl Computer.hdl   Part A — put these in projects/05
assembler.py                      Part B — two-pass assembler
Box.asm  Box.hack  symbols.txt    Part C — the box, row 81, 32 px wide
tests/                            Add, Max, Rect and their .hack output
REPORT.md                         report draft (fill in name + screenshots)
VIVA_NOTES.md                     what gets asked, and the live modification
```
