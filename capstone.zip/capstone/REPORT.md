# Capstone Project — Make the Computer Draw a Box

**Course:** Nand to Tetris – I (ETCNTC301)
**Name:** _______________________
**Roll number:** 2501730081
**Personal number K:** **81**

---

## 1. My K and what it decides

K is the last two digits of my roll number 25017300**81**, so **K = 81**.

| Quantity | Formula | My value |
|---|---|---|
| Assembler feature | K mod 3 = 81 mod 3 | **0** → write `symbols.txt` |
| Box starting row | K | **81** |
| Box height | fixed | 20 rows → rows 81 to 100 |
| Box width | 16 × ((K mod 4) + 1) = 16 × ((81 mod 4) + 1) = 16 × 2 | **32 pixels** |
| Words per row | width ÷ 16 | **2** |
| Address of first word | SCREEN + 32 × 81 = 16384 + 2592 | **18976** |

---

## 2. Part A — the Hack computer

### CPU.hdl

The CPU receives one 16-bit instruction. Bit 15 decides everything else:

- **0 → A-instruction.** The remaining 15 bits are a constant, loaded into A.
- **1 → C-instruction.** The bits are fields: `a` picks the ALU's second
  input, `cccccc` are the ALU control bits, `ddd` says where to store the
  result, `jjj` says when to jump.

The parts I had to think about:

**A register load.** A is written in two different situations — on every
A-instruction, and on a C-instruction whose `d1` bit is set. So the load
signal is `Or(isA, instruction[5])`, and a mux picks whether the value coming
in is the instruction itself or the ALU output.

**The a-bit.** `instruction[12]` chooses between A and M as the ALU's `y`
input, but only on a C-instruction. On an A-instruction those bits are part of
a constant and mean nothing, so the select is `And(instruction[15],
instruction[12])`.

**Jump logic.** The ALU reports `zr` (result is zero) and `ng` (result is
negative). There is no "greater than zero" output, because it is not needed —
greater than zero is simply *neither zero nor negative*, which is one `And` of
two `Not`s. The three jump bits are then matched against these three
conditions and OR-ed together, and the whole thing is gated by
`instruction[15]` so an A-instruction can never jump.

**The PC.** `inc` is wired permanently to `true`. Inside the PC chip `load`
beats `inc` and `reset` beats both, so "jump if the condition holds, otherwise
carry on to the next instruction" needs no extra logic.

### Memory.hdl

The 15-bit address space holds three different things:

| Range | Region | Selected by |
|---|---|---|
| 0 – 16383 | RAM16K | `address[14] = 0` |
| 16384 – 24575 | Screen | `address[14] = 1`, `address[13] = 0` |
| 24576 | Keyboard | `address[14] = 1`, `address[13] = 1` |

So `address[13..14]` picks the region. A `DMux4Way` routes the `load` signal to
the right chip and a `Mux4Way16` picks the right output. The RAM takes two of
the four slots because it is twice the size of the other regions. The keyboard
is read-only, so its load line is left unconnected.

### Computer.hdl

Three chips in a loop: the PC addresses the ROM, the ROM hands the CPU an
instruction, the CPU reads or writes the Memory and produces the next PC.

**Test results:** _(insert screenshots of CPU.tst, Memory.tst and
Computer.tst passing)_

---

## 3. Part B — the two-pass assembler

### Why two passes

A label can be used before it is declared:

```
    @END        <- at this point we do not know what END is
    0;JMP
  (END)
```

A single pass would reach `@END` with no idea what address to write. So the
first pass does nothing but find out where things are, and the second pass
translates with every address already known.

### First pass — labels

Walk the cleaned lines, keeping a count of real instructions. A label is not
an instruction and takes no ROM slot, so when `(LOOP)` appears, the address it
stands for is the current count — the address of whatever instruction comes
next. Comments and blank lines are stripped first, but the original line
numbers are kept so an error message can point at the line as it appears in
the file.

### Second pass — binary

Each line becomes one 16-bit word:

- `@value` → `0` followed by the 15-bit number.
- `@symbol` → look it up. If it is predefined (`R0`–`R15`, `SP`, `SCREEN`,
  `KBD`, …) or a label found in pass one, use that address. Otherwise it is a
  **variable** appearing for the first time: allocate the next free RAM
  address, starting at 16 and counting up, and remember it so the same name
  gets the same address next time.
- `dest=comp;jump` → `111` + the six `comp` bits + three `dest` bits + three
  `jump` bits, each from a lookup table.

### Testing

| Program | Result |
|---|---|
| `Add.asm` | output matches the official assembler exactly |
| `Max.asm` | output matches the official assembler exactly |
| `Rect.asm` | labels `LOOP = 10`, `INFINITE_LOOP = 23`; variables `counter = 16`, `address = 17` |
| `Pong.asm` | _(run it and record the result)_ |

I also checked the output a second way: every generated `.hack` file was
decoded back into assembly and compared against the source. All instructions
decoded back correctly, which catches an encoding mistake that a
label-counting test would miss.

---

## 4. Additional feature — K mod 3 = 0

> *Save all labels and variables with their addresses in `symbols.txt`.*

After assembling, the program writes `symbols.txt` listing what the two passes
worked out. Labels and variables are listed separately, because they are
different kinds of address:

- a **label** is a **ROM** address — where an instruction sits in the program
- a **variable** is a **RAM** address — where a value is stored

In the instruction they are both just numbers, so listing them side by side
makes it obvious if something was picked up as the wrong kind. For my
`Box.asm`:

```
LABELS  (ROM addresses -- where an instruction is)
  MAIN                         0
  SETBLACK                     8
  PAINT                       10
  ROWLOOP                     20
  COLLOOP                     32
  NEXTROW                     47

VARIABLES  (RAM addresses, allocated from 16 upward)
  colour                      16
  addr                        17
  rows                        18
  cols                        19
  p                           20
```

---

## 5. Part C — Box.asm

### Screen memory

- The screen map starts at `SCREEN` = 16384.
- Each row is **32 words**; each word is **16 horizontal pixels**; so the
  screen is 512 pixels wide.
- Row *r* begins at `SCREEN + 32 × r`.
- Writing **−1** (all sixteen bits on) blacks out those 16 pixels; writing
  **0** clears them.

### My box

Starting row 81, so the first word is at `16384 + 32 × 81 = 18976`. Width is
32 pixels, which is **2 words** per row, taken from the left edge — word
offsets 0 and 1. Height is 20 rows, so rows 81 to 100.

### How the program works

```
MAIN      read KBD. non-zero -> colour = -1, zero -> colour = 0
PAINT     addr = 18976, rows = 20
ROWLOOP   rows == 0 ? -> back to MAIN
          cols = 2, p = addr
COLLOOP   cols == 0 ? -> NEXTROW
          write colour to RAM[p], p = p + 1, cols = cols - 1
NEXTROW   addr = addr + 32, rows = rows - 1 -> ROWLOOP
```

Drawing and erasing use the **same loop** — only the value written changes.
Writing the loop twice, once for black and once for white, is the obvious
approach and also the easy way to get the two copies out of step when
something is changed later.

The whole thing repeats forever, so the keyboard is re-read after every full
repaint and the box appears and disappears as the key is pressed and released.

**Screenshot:** _(insert a screenshot of the box in the CPU Emulator with a key
held down)_

---

## 6. A mistake I made and how I fixed it

> **Write your own here — the viva will ask about it.** Some things that
> genuinely trip people up on this project, in case one of them matches what
> happened to you:
>
> - **`M=M+32` does not assemble.** The Hack C-instruction can only add 1, or
>   add two registers. To step `addr` on by a row you must load the constant
>   first: `@32 / D=A / @addr / M=D+M`.
> - **`A=M` clobbers A.** After `@p / A=M`, the A register no longer holds the
>   address of `p` — it holds the value stored there. Writing `M=D` then
>   `M=M+1` in a row increments the *screen word*, not the pointer.
> - **The jump is on the ALU output, not on A.** `D;JEQ` tests whatever the
>   ALU just computed. Loading something into D and jumping several
>   instructions later tests a stale value.
> - **Forgetting the gate on `instruction[15]`** in the CPU, so A-instructions
>   jump and the program runs away.

---

## 7. Files submitted

```
capstone/
  CPU.hdl
  Memory.hdl
  Computer.hdl
  assembler.py
  Box.asm
  Box.hack
  symbols.txt
  tests/   Add.asm  Max.asm  Rect.asm  and their .hack output
```
