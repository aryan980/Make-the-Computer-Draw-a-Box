"""Hack assembler: turns a .asm file into the 16-bit machine code a Hack CPU runs.

It reads the program twice, which is the whole reason the thing works.

A label can be used before it is declared:

        @END        <- we do not know what END is yet
        0;JMP
    (END)

So the first pass does nothing but walk the instructions and note where each
label lands. The second pass can then translate every instruction knowing all
the addresses in advance.

usage:  python assembler.py Prog.asm            -> writes Prog.hack
        python assembler.py Prog.asm out.hack
"""

import os
import sys

# ---------------------------------------------------------------------------
# instruction tables
# ---------------------------------------------------------------------------

# The six c-bits. The left column is for a=0 (the ALU's y input is A), and the
# same computations with M instead of A are a=1 with identical c-bits.
COMP = {
    "0":   "0101010", "1":   "0111111", "-1":  "0111010",
    "D":   "0001100", "A":   "0110000", "!D":  "0001101",
    "!A":  "0110001", "-D":  "0001111", "-A":  "0110011",
    "D+1": "0011111", "A+1": "0110111", "D-1": "0001110",
    "A-1": "0110010", "D+A": "0000010", "D-A": "0010011",
    "A-D": "0000111", "D&A": "0000000", "D|A": "0010101",
}
for _mnemonic, _bits in list(COMP.items()):
    if "A" in _mnemonic:
        COMP[_mnemonic.replace("A", "M")] = "1" + _bits[1:]

# Addition and the bitwise operations commute, so accept them written either
# way round. The official assembler is strict here; being lenient costs
# nothing and avoids a confusing error over something that is not an error.
for _a, _b in [("D+A", "A+D"), ("D+M", "M+D"),
               ("D&A", "A&D"), ("D&M", "M&D"),
               ("D|A", "A|D"), ("D|M", "M|D")]:
    COMP[_b] = COMP[_a]

DEST = {None: "000", "M": "001", "D": "010", "MD": "011",
        "A": "100", "AM": "101", "AD": "110", "AMD": "111"}

JUMP = {None: "000", "JGT": "001", "JEQ": "010", "JGE": "011",
        "JLT": "100", "JNE": "101", "JLE": "110", "JMP": "111"}

PREDEFINED = {
    "SP": 0, "LCL": 1, "ARG": 2, "THIS": 3, "THAT": 4,
    "SCREEN": 16384, "KBD": 24576,
}
for _i in range(16):
    PREDEFINED["R%d" % _i] = _i

FIRST_VARIABLE_ADDRESS = 16


class AssemblyError(Exception):
    """Raised with a line number so the message can point at the mistake."""


# ---------------------------------------------------------------------------
# reading the source
# ---------------------------------------------------------------------------

def clean(path):
    """Strip comments and blank lines, keeping each line's original number.

    Returns a list of (line_number, text). The line numbers are kept so that
    an error can name the line as it appears in the file the student wrote,
    not the line it became after the blanks were dropped.
    """
    out = []
    with open(path, "r", encoding="utf-8") as f:
        for number, raw in enumerate(f, start=1):
            text = raw.split("//")[0].strip()
            if text:
                out.append((number, text))
    return out


# ---------------------------------------------------------------------------
# first pass: find the labels
# ---------------------------------------------------------------------------

def first_pass(lines):
    """Record the address each (LABEL) points at.

    A label is not an instruction, so it does not take up a slot in the ROM.
    The address it stands for is the address of whatever instruction comes
    next -- which is exactly the running count of real instructions so far.

    Returns (symbols, labels): symbols is the full table the second pass
    works from, labels is just the ones declared in this program, kept
    separately so symbols.txt can tell them apart from the variables.
    """
    symbols = dict(PREDEFINED)
    labels = {}
    address = 0

    for number, text in lines:
        if text.startswith("("):
            if not text.endswith(")"):
                raise AssemblyError("Line %d: label is missing its closing ')'"
                                    % number)
            name = text[1:-1].strip()
            if not name:
                raise AssemblyError("Line %d: empty label" % number)
            symbols[name] = address
            labels[name] = address
        else:
            address += 1

    return symbols, labels


# ---------------------------------------------------------------------------
# second pass: translate
# ---------------------------------------------------------------------------

def parse_c_instruction(text, number):
    """Split  dest=comp;jump  into its three parts. dest and jump are optional."""
    dest = jump = None
    body = text

    if "=" in body:
        dest, body = body.split("=", 1)
        dest = dest.strip()
    if ";" in body:
        body, jump = body.split(";", 1)
        jump = jump.strip()

    comp = body.strip().replace(" ", "")

    if dest is not None and dest not in DEST:
        raise AssemblyError("Line %d: '%s' is not a valid destination" % (number, dest))
    if jump is not None and jump not in JUMP:
        raise AssemblyError("Line %d: '%s' is not a valid jump" % (number, jump))
    if comp not in COMP:
        raise AssemblyError("Line %d: '%s' is not a valid computation" % (number, comp))

    return "111" + COMP[comp] + DEST[dest] + JUMP[jump]


def valid_symbol(name):
    """Hack symbols: letters, digits, _ . $ : -- and never start with a digit."""
    if not name or name[0].isdigit():
        return False
    return all(c.isalnum() or c in "_.$:" for c in name)


def second_pass(lines, symbols):
    """Translate every instruction, allocating variables as they first appear.

    Returns (code, variables).
    """
    code = []
    variables = {}
    next_variable = FIRST_VARIABLE_ADDRESS

    for number, text in lines:
        if text.startswith("("):
            continue                                  # handled in pass one

        if text.startswith("@"):
            operand = text[1:].strip()

            if operand.isdigit():
                value = int(operand)
            elif operand in symbols:
                value = symbols[operand]
            elif valid_symbol(operand):
                # Not a label and not seen before, so it is a new variable.
                # Variables live in RAM from 16 upward, one slot each.
                value = next_variable
                symbols[operand] = value
                variables[operand] = value
                next_variable += 1
            else:
                raise AssemblyError("Line %d: '@%s' is not a valid address or symbol"
                                    % (number, operand))

            if value > 32767:
                raise AssemblyError("Line %d: @%d does not fit in 15 bits"
                                    % (number, value))
            code.append(format(value, "016b"))
        else:
            code.append(parse_c_instruction(text, number))

    return code, variables


# ---------------------------------------------------------------------------
# additional feature  --  K = 81, and 81 mod 3 = 0
#   "Save all labels and variables with their addresses in symbols.txt"
# ---------------------------------------------------------------------------

def write_symbol_file(path, labels, variables):
    """Write out what the two passes worked out, for checking by eye.

    The two kinds of symbol are listed apart because they mean different
    things. A label is a ROM address -- where an instruction sits in the
    program. A variable is a RAM address -- where a value is stored. They
    are both just numbers in the instruction, so seeing them side by side
    makes it easy to spot a label that was meant to be a variable.
    """
    with open(path, "w", encoding="utf-8") as f:
        f.write("LABELS  (ROM addresses -- where an instruction is)\n")
        if labels:
            for name, address in sorted(labels.items(), key=lambda kv: kv[1]):
                f.write("  %-24s %5d\n" % (name, address))
        else:
            f.write("  (none)\n")

        f.write("\nVARIABLES  (RAM addresses, allocated from %d upward)\n"
                % FIRST_VARIABLE_ADDRESS)
        if variables:
            for name, address in sorted(variables.items(), key=lambda kv: kv[1]):
                f.write("  %-24s %5d\n" % (name, address))
        else:
            f.write("  (none)\n")


# ---------------------------------------------------------------------------
# main
# ---------------------------------------------------------------------------

def assemble(src, dst=None):
    if dst is None:
        dst = os.path.splitext(src)[0] + ".hack"

    lines = clean(src)
    symbols, labels = first_pass(lines)
    code, variables = second_pass(lines, symbols)

    with open(dst, "w", encoding="utf-8") as f:
        f.write("\n".join(code) + "\n")

    sym_path = os.path.join(os.path.dirname(os.path.abspath(dst)), "symbols.txt")
    write_symbol_file(sym_path, labels, variables)

    return dst, len(code), sym_path, len(labels), len(variables)


def main(argv):
    if len(argv) < 2:
        print(__doc__)
        return 1

    src = argv[1]
    dst = argv[2] if len(argv) > 2 else None

    try:
        out, count, sym_path, n_labels, n_vars = assemble(src, dst)
    except AssemblyError as e:
        print("Assembly failed.")
        print(" ", e)
        return 1
    except FileNotFoundError:
        print("No such file:", src)
        return 1

    print("Wrote %s  (%d instructions)" % (out, count))
    print("Wrote %s  (%d labels, %d variables)" % (sym_path, n_labels, n_vars))
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
